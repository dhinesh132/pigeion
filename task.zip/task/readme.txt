Kindly follow these steps

1) Unzip pigeon folder upload on your htdocs directory

2) Import "pigeon_db sql into your phpmyadmin

3) change .env file

4) sample login 

user name: mdhinesh.kannan2gmail.com  
pwd : password

5) API URL 

http://localhost/pigeon/public/api/pigeon/3
http://localhost/pigeon/public/api/order/3

